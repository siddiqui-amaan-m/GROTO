package com.example.driveforgroto;

import android.content.Intent;
import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.firebase.auth.FirebaseAuth;

public class Amaan extends FragmentActivity  {

    private GoogleMap mMap;
    Location mLastLocation;
    LocationRequest mLocationRequest;

    private ImageButton mLogout, mSettings;
    private Button mEndRide, mRec, mNrec;

    private FusedLocationProviderClient mFusedLocationClient;

    private String customerId = "", cn = "", cp = "";
    private Boolean isLoggingOut = false;
    private TextView mFuel, mSpeed;
    private SupportMapFragment mapFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_amaan);
        final String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.

        // 13jan mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);




        /* 13jan if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED ){}
        else {
            mapFragment.getMapAsync(this);
        }*/

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(this);


        mSettings = (ImageButton) findViewById(R.id.settings);
        mFuel = (TextView) findViewById(R.id.fuel);
        mSpeed = (TextView) findViewById(R.id.speed);
        mLogout = (ImageButton) findViewById(R.id.logout);
        mLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                isLoggingOut = true;

                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(Amaan.this, MainActivity.class);
                startActivity(intent);
                finish();
                return;
            }
        });

        mSettings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Amaan.this, DriverSettingsActivity.class);
                startActivity(intent);
                return;
            }
        });

    }


}
