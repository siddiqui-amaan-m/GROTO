package com.example.driveforgroto;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class RecyclePhoneActivity extends AppCompatActivity {

    public String number;
    private static final int REQUEST_CALL = 1;
    private ImageButton b1;
    private ImageButton b2;
    private ImageButton b3;
    private ImageButton b4;
    private ImageButton b5;
    private ImageButton b6;
    private ImageButton b7;
    private ImageButton b8;
    private ImageButton b9;
    private ImageButton b10;
    private ImageButton b11;
    private ImageButton b12;
    private ImageButton b13;
    private ImageButton b14;
    private ImageButton b15;
    private ImageButton b16;
    private ImageButton b17;
    private ImageButton b18;
    private ImageButton b19;
    private ImageButton b20;
    private ImageButton b21;
    private ImageButton b22;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_municipal);
        b1= (ImageButton) findViewById(R.id.b1);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "(866) 2421058 2422400";
                makePhoneCall();

            }
        });

        b2= (ImageButton) findViewById(R.id.b2);
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "97400 57778";
                makePhoneCall();

            }
        });

        b3= (ImageButton) findViewById(R.id.b3);
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "8811007000";
                makePhoneCall();

            }
        });

        b4= (ImageButton) findViewById(R.id.b4);
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 345 6644";
                makePhoneCall();

            }
        });

        b5= (ImageButton) findViewById(R.id.b5);
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 121 6505";
                makePhoneCall();

            }
        });

        b6= (ImageButton) findViewById(R.id.b6);
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "18002333948";
                makePhoneCall();

            }
        });

        b7= (ImageButton) findViewById(R.id.b7);
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "79 2535 0926";
                makePhoneCall();

            }
        });

        b8= (ImageButton) findViewById(R.id.b8);
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "18001808101";
                makePhoneCall();

            }
        });

        b9= (ImageButton) findViewById(R.id.b9);
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "18001803012";
                makePhoneCall();

            }
        });

        b10= (ImageButton) findViewById(R.id.b10);
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "06512211215";
                makePhoneCall();

            }
        });

        b11= (ImageButton) findViewById(R.id.b11);
        b11.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "080 23003100";
                makePhoneCall();

            }
        });

        b12= (ImageButton) findViewById(R.id.b12);
        b12.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "0474-2742192";
                makePhoneCall();

            }
        });

        b13= (ImageButton) findViewById(R.id.b13);
        b13.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = " 1800 3000 7141 ";
                makePhoneCall();

            }
        });

        b14= (ImageButton) findViewById(R.id.b14);
        b14.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "18001030222";
                makePhoneCall();

            }
        });

        b15= (ImageButton) findViewById(R.id.b15);
        b15.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "18002700038";
                makePhoneCall();

            }
        });

        b16= (ImageButton) findViewById(R.id.b16);
        b16.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "93300 89998";
                makePhoneCall();

            }
        });

        b17= (ImageButton) findViewById(R.id.b17);
        b17.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 2707666";
                makePhoneCall();

            }
        });

        b18= (ImageButton) findViewById(R.id.b18);
        b18.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 270 7666";
                makePhoneCall();

            }
        });

        b19= (ImageButton) findViewById(R.id.b19);
        b19.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "80180 60102";
                makePhoneCall();

            }
        });

        b20= (ImageButton) findViewById(R.id.b20);
        b20.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 270 7666";
                makePhoneCall();

            }
        });

        b21= (ImageButton) findViewById(R.id.b21);
        b21.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 270 7666";
                makePhoneCall();

            }
        });

        b22= (ImageButton) findViewById(R.id.b22);
        b22.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = "1800 270 7666";
                makePhoneCall();

            }
        });




    }

    private void makePhoneCall() {


        if (number.trim().length() > 0) {
            if (ContextCompat.checkSelfPermission(RecyclePhoneActivity.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(RecyclePhoneActivity.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                startActivity(new Intent(Intent.ACTION_CALL, Uri.parse(dial)));
            }
        }

    }

    @Override
    public void onRequestPermissionsResult ( int requestCode, @NonNull String[] permissions,
                                             @NonNull int[] grantResults){
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
