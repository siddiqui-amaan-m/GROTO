package com.example.driveforgroto;


import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.text.TextUtils;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.os.Handler;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.LogRecord;

public class AdminActivity extends AppCompatActivity {

    private TextView mNameField, mPhoneField, mCarField;
    private FirebaseAuth.AuthStateListener firebaseAuthListener;
    private ImageButton mAccept, mReject;
    private ImageView mProfileImage;
    private ImageView midImage;
    private FirebaseAuth mAuth;
    private String mNewDriver;
    private DatabaseReference mDriverDatabase;
    private DatabaseReference mNewDriverDatabase;
    private String userID;
    private String mName;
    private String mPhone;
    private String mCar;
    private String mProfileImageUrl;
    private String mIDproofUrl;
    private Uri resultUri;
    private static String iddr;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);


        final LoadingDialog loadingDialog = new LoadingDialog(AdminActivity.this);

        mNameField = (TextView) findViewById(R.id.name);
        mPhoneField = (TextView) findViewById(R.id.phone);
        mCarField = (TextView) findViewById(R.id.car);

        mProfileImage = (ImageView) findViewById(R.id.profileImage);
        midImage = (ImageView) findViewById(R.id.idImage);

        mAccept = (ImageButton) findViewById(R.id.accept);
        mReject = (ImageButton) findViewById(R.id.reject);


        mAuth = FirebaseAuth.getInstance();
        userID = FirebaseAuth.getInstance().getCurrentUser().getUid();
        mNewDriverDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Admins").child(userID);




        /*mNewDriverDatabase.limitToLast(1).addChildEventListener(new ValueEventListener()
          {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                    iddr = dataSnapshot.getValue().toString();


            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });*/

        mNewDriverDatabase.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                iddr=dataSnapshot.getValue().toString();
                mDriverDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Drivers").child(iddr);
                getUserInfo();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                setContentView(R.layout.avtivity_plain);

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });








        //if(iddr.equals(null))
          //  setContentView(R.layout.avtivity_plain);
            //loadingDialog.dismissDialog();



        loadingDialog.startLoadingDialog();
        Handler handler= new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                loadingDialog.dismissDialog();
            }
        },15000);





        mAccept.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View view) {
                                           Toast.makeText(AdminActivity.this, "Thank you for accepting", Toast.LENGTH_SHORT).show();
                                           mDriverDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Admins").child(userID);
                                           mDriverDatabase.setValue(null);
                                           setContentView(R.layout.avtivity_plain);
                                       }
                                   });


        mReject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(AdminActivity.this, "Thank you for rejecting", Toast.LENGTH_SHORT).show();
                mDriverDatabase = FirebaseDatabase.getInstance().getReference().child("Users").child("Admins").child(userID);
                mDriverDatabase.setValue(null);
                setContentView(R.layout.avtivity_plain);
                //return;
            }
        });


    }
    private void getUserInfo(){
        mDriverDatabase.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                if(dataSnapshot.exists() && dataSnapshot.getChildrenCount()>0){
                    Map<String, Object> map = (Map<String, Object>) dataSnapshot.getValue();
                    if(map.get("name")!=null){
                        mName = map.get("name").toString();
                        mNameField.setText(mName);
                    }
                    if(map.get("phone")!=null){
                        mPhone = map.get("phone").toString();
                        mPhoneField.setText(mPhone);
                    }
                    if(map.get("car")!=null){
                        mCar = map.get("car").toString();
                        mCarField.setText(mCar);
                    }
                    if(map.get("profileImageUrl")!=null){
                        mProfileImageUrl = map.get("profileImageUrl").toString();
                        Glide.with(getApplication()).load(mProfileImageUrl).into(mProfileImage);
                    }
                    if(map.get("IDproofUrl")!=null){
                        mIDproofUrl = map.get("IDproofUrl").toString();
                        Glide.with(getApplication()).load(mIDproofUrl).into(midImage);
                    }

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
            }
        });
    }









    /*@Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1 && resultCode == Activity.RESULT_OK){
            final Uri imageUri = data.getData();
            resultUri = imageUri;
            mProfileImage.setImageURI(resultUri);
        }
    }*/



}


